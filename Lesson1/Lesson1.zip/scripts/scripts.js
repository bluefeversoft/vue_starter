new Vue(
{
	el: '#simpleApp',
	data: {
		someText: 'I need a beer'
	}
}
);