new Vue(
{
	el: '#simpleApp',
	data: {
		showAlert: false
	}
}
);